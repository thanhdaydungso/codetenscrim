// ==== Đọc & đếm team ====
function getTeams() {
  return document.getElementById('teamInput').value
    .split('\n')
    .map(function (t) { return t.trim(); })
    .filter(function (t) { return t.length > 0; });
}

function updateCount() {
  var teams = getTeams();
  document.getElementById('countInfo').textContent = 'Số team đã nhập: ' + teams.length;
}

var currentGroups = [];

// ==== Random & chia bảng ====
function doRandom() {
  var errorEl = document.getElementById('errorMsg');
  errorEl.style.display = 'none';
  var teams = getTeams();
  var perGroup = parseInt(document.getElementById('perGroup').value, 10);

  if (teams.length === 0) {
    errorEl.textContent = 'Nhập danh sách team trước đã.';
    errorEl.style.display = 'block';
    document.getElementById('results').innerHTML = '';
    document.getElementById('btnExport').style.display = 'none';
    return;
  }
  if (!perGroup || perGroup < 1) {
    errorEl.textContent = 'Số team mỗi bảng phải là số nguyên dương.';
    errorEl.style.display = 'block';
    return;
  }

  var shuffled = shuffle(teams);

  var groups = [];
  for (var k = 0; k < shuffled.length; k += perGroup) {
    groups.push(shuffled.slice(k, k + perGroup));
  }
  currentGroups = groups;
  renderGroups(groups);
  document.getElementById('btnExport').style.display = 'inline-block';
}

// Fisher-Yates shuffle
function shuffle(arr) {
  var a = arr.slice();
  for (var i = a.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1));
    var tmp = a[i]; a[i] = a[j]; a[j] = tmp;
  }
  return a;
}

// ==== Hiển thị kết quả ====
function renderGroups(groups) {
  var html = '';
  for (var i = 0; i < groups.length; i++) {
    html += '<div class="group-card">';
    html += '<div class="group-title">BẢNG ' + (i + 1) + ' (' + groups[i].length + ')</div>';
    html += '<ol>';
    for (var j = 0; j < groups[i].length; j++) {
      html += '<li>' + escapeHtml(groups[i][j]) + '</li>';
    }
    html += '</ol></div>';
  }
  document.getElementById('results').innerHTML = html;
}

function escapeHtml(str) {
  var div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ==== Xuất Excel (dùng ExcelJS) ====
async function exportExcel() {
  if (!currentGroups.length || !window.ExcelJS) return;

  var wb = new ExcelJS.Workbook();
  var ws = wb.addWorksheet('Chia bảng');

  ws.columns = [
    { header: 'BẢNG', key: 'bang', width: 10 },
    { header: 'TÊN ĐỘI', key: 'team', width: 32 }
  ];

  var headerRow = ws.getRow(1);
  headerRow.eachCell(function (cell) {
    cell.font = { bold: true };
    cell.alignment = { horizontal: 'center', vertical: 'middle' };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE6F1FB' } };
    cell.border = borderAll();
  });

  var rowIndex = 2;
  for (var i = 0; i < currentGroups.length; i++) {
    var group = currentGroups[i];
    var startRow = rowIndex;
    for (var j = 0; j < group.length; j++) {
      var row = ws.addRow({ bang: (j === 0 ? (i + 1) : null), team: group[j] });
      row.getCell(1).alignment = { horizontal: 'center', vertical: 'middle' };
      row.getCell(2).alignment = { horizontal: 'left', vertical: 'middle' };
      row.getCell(1).border = borderAll();
      row.getCell(2).border = borderAll();
      rowIndex++;
    }
    var endRow = rowIndex - 1;
    if (endRow > startRow) {
      ws.mergeCells('A' + startRow + ':A' + endRow);
      ws.getCell('A' + startRow).font = { bold: true };
    }
  }

  var buffer = await wb.xlsx.writeBuffer();
  var blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url;
  a.download = 'chia_bang.xlsx';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function borderAll() {
  return {
    top: { style: 'thin' },
    left: { style: 'thin' },
    bottom: { style: 'thin' },
    right: { style: 'thin' }
  };
}

// ==== Gắn sự kiện ====
document.getElementById('teamInput').addEventListener('input', updateCount);
document.getElementById('btnRandom').addEventListener('click', doRandom);
document.getElementById('btnExport').addEventListener('click', exportExcel);
updateCount();
